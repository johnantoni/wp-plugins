<?php

/**
 * Plugin Name: mPress Hide from Search
 * Plugin URI: http://micahwood.me/wordpress-plugins/mpress-hide-from-search/
 * Description: Hide individual public pages from WordPress search.  Great for hiding confirmation and download pages
 * that need to be public, but should only be accessible via a squeeze page.
 * Version: 0.2
 * Author: Micah Wood
 * Author URI: http://micahwood.me/
 * License: GPLv3
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 *
 * Copyright 2012 by Micah Wood - All rights reserved.
 */

define( 'MPRESS_HIDE_FROM_SEARCH_VERSION', '0.2' );

if ( ! class_exists( 'mPress_Hide_From_Search' ) ) {

	class mPress_Hide_From_Search {

		private static $instance = false;

		private $meta_key = '_mpress_hide_from_search',
				$nonce_name = '_mpress_hide_from_search_nonce';

		public static function get_instance() {
			return self::$instance ? self::$instance : new self();
		}

		private function __construct() {
			self::$instance = $this;
			add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ) );
			add_action( 'save_post', array( $this, 'save_post' ) );
			add_filter( 'posts_where', array( $this, 'posts_where' ) );
		}

		function add_meta_boxes() {
			foreach( get_post_types( array( 'exclude_from_search' => false ) ) as $post_type )
				add_meta_box( 'hide-from-search',
					__('Hide from Search', 'mpress-hide-from-search'),
					array( $this, 'meta_box_content' ),
					$post_type, 'side', 'low'
				);
		}

		function meta_box_content() {
			global $post;
			$checked = get_post_meta( $post->ID, $this->meta_key, true ) ? ' checked="checked"': false;
			$post_type_obj = get_post_type_object( get_post_type( $post->ID ) );
			wp_nonce_field( __FILE__, $this->nonce_name );
			echo "<input type=\"checkbox\" name=\"{$this->meta_key}\" value=\"1\"{$checked} /> ";
			printf( __( 'Hide this %s from WordPress search', 'mpress-hide-from-search' ),
				strtolower( $post_type_obj->labels->singular_name )
			);
		}

		function save_post( $post_id ) {
			if( ! isset( $_POST[$this->nonce_name] ) ) return;
			if( ! wp_verify_nonce( $_POST[$this->nonce_name], __FILE__ ) ) return;
			if( ! current_user_can( 'edit_post', $post_id ) ) return;
			$value = isset( $_POST[$this->meta_key] ) ? (boolean) $_POST[$this->meta_key]: false;
			if( $value )
				update_post_meta( $post_id, $this->meta_key, 1 );
			else
				delete_post_meta( $post_id, $this->meta_key );
		}

		function posts_where( $where ) {
			global $wpdb;
			if( is_search() )
				$where .= " AND ID NOT IN ( SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '{$this->meta_key}' AND meta_value = 1 )";
			return $where;
		}

	}

	mPress_Hide_From_Search::get_instance();

}