=== Widgets Controller  ===
Contributors: indianic
Donate link: 
Tags: widgets control, widgets controller, widgets controlar, widget controlar, manage widgets, dynamic widget, dynamic widgets, widget logic, widget setting, hide widget, sidebar controller, custom widget, custom widgets, conditional widget, conditional widgets, display widget, display widgets
Requires at least: 3.0
Tested up to: 3.4.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A plugin that give you control for show or hide widgets.

== Description ==
Want to mange your widget the way you want? Well, the widget controller is very imperative application for managing your page-widget. This allows you to show or hide the widgets content just on few mouse clicks. There is no knowledge of PHP required. With the ease of installation, Widgets Controller is a smart plug-in with smart features.
= Features =
<ul>
<li>Ease of widget maintenance - have the widgets on particular page of your website</li>
<li>Active category services - selection of posts and pages can be managed by selecting category services</li>
<li>Check All and Uncheck ALL services</li>
<li>404 Page facility</li>
<li>Home page and search page facility.</li>
</ul>
<p><a href="http://www.indianic.com/"><strong>Visit Our Website</strong></a></p>
== Installation ==
1. Upload `widgets-controller` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Visit the Appearance -> Widgets
   You can show Widget Controller options below every Widget.
4. Edit the desired widgets.

== Frequently Asked Questions ==
Have a question? Email me at submission@indianic.com

== Screenshots ==
1. screenshot-1.png
2. screenshot-2.png
3. screenshot-3.png
4. screenshot-4.png

== Changelog ==

= 1.1 =
* Changes in Design.

= 1.0 =
* Set up basic functionality

== Upgrade Notice ==

= 1.0 =
* No currently update found.