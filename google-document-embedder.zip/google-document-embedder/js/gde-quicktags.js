edButtons[edButtons.length] =
new edButton('ed_h1'
	,'GDE'
	,'[gview file="'
	,'"]'
	,'1'
);